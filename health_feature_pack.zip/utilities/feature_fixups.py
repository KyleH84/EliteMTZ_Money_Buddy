
# utilities/feature_fixups.py
import numpy as np
import pandas as pd

def _to_numeric(df: pd.DataFrame, cols):
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce')
    return df

def compute_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    s = pd.to_numeric(series, errors='coerce')
    delta = s.diff()
    up = delta.clip(lower=0.0)
    down = -delta.clip(upper=0.0)
    roll_up = up.ewm(alpha=1/period, adjust=False).mean()
    roll_down = down.ewm(alpha=1/period, adjust=False).mean()
    rs = roll_up / roll_down.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi

def compute_connors_rsi(close: pd.Series, period_rsi=3, period_streak=2, period_rank=100) -> pd.Series:
    rsi = compute_rsi(close, period_rsi)
    delta = close.diff()
    streak = pd.Series(0, index=close.index, dtype=float)
    for i in range(1, len(close)):
        if np.isnan(delta.iloc[i]) or np.isnan(delta.iloc[i-1]):
            streak.iloc[i] = 0
        elif delta.iloc[i] > 0:
            streak.iloc[i] = streak.iloc[i-1] + 1 if streak.iloc[i-1] > 0 else 1
        elif delta.iloc[i] < 0:
            streak.iloc[i] = streak.iloc[i-1] - 1 if streak.iloc[i-1] < 0 else -1
        else:
            streak.iloc[i] = 0
    streak_rsi = compute_rsi(streak, period_streak)
    change = delta / close.shift(1) * 100.0
    def pr(s, n):
        return s.rolling(n).apply(lambda x: pd.Series(x).rank(pct=True).iloc[-1] * 100, raw=False)
    pct_rank = pr(change, period_rank)
    return (rsi + streak_rsi + pct_rank) / 3.0

def compute_rvol(volume: pd.Series, window: int = 20) -> pd.Series:
    v = pd.to_numeric(volume, errors='coerce')
    ma = v.rolling(window).mean()
    return v / ma

def compute_relspy(stock_close: pd.Series, spy_close: pd.Series, lookback: int = 20) -> pd.Series:
    sc = pd.to_numeric(stock_close, errors='coerce')
    sp = pd.to_numeric(spy_close.reindex(sc.index), errors='coerce')
    with np.errstate(divide='ignore', invalid='ignore'):
        s_ret = sc / sc.shift(lookback)
        spy_ret = sp / sp.shift(lookback)
        rel = s_ret / spy_ret
    return rel

def compute_squeeze_hint(close: pd.Series, high: pd.Series, low: pd.Series, window=20, mult_bb=2.0, mult_kc=1.5) -> pd.Series:
    c = pd.to_numeric(close, errors='coerce')
    h = pd.to_numeric(high, errors='coerce')
    l = pd.to_numeric(low, errors='coerce')
    mid = c.rolling(window).mean()
    std = c.rolling(window).std()
    bb_width = (mid + mult_bb*std) - (mid - mult_bb*std)
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(window).mean()
    kc_width = 2 * mult_kc * atr
    return (bb_width < kc_width).astype(float)

def fill_feature_gaps(df: pd.DataFrame, spy_ref: pd.DataFrame | None = None,
                      price_cols=('Close','High','Low'), vol_col='Volume') -> pd.DataFrame:
    df = df.copy()
    need_num = [c for c in [*price_cols, vol_col] if c in df.columns]
    df = _to_numeric(df, need_num)

    close = df[price_cols[0]] if price_cols[0] in df.columns else None
    high = df[price_cols[1]] if len(price_cols) > 1 and price_cols[1] in df.columns else None
    low  = df[price_cols[2]] if len(price_cols) > 2 and price_cols[2] in df.columns else None
    vol  = df[vol_col] if vol_col in df.columns else None

    if 'RSI4' not in df.columns or df['RSI4'].isna().all():
        if close is not None:
            df['RSI4'] = compute_rsi(close, 4)

    if 'ConnorsRSI' not in df.columns or df['ConnorsRSI'].isna().all():
        if close is not None:
            df['ConnorsRSI'] = compute_connors_rsi(close)

    if 'RVOL' not in df.columns or df['RVOL'].isna().all():
        if vol is not None:
            df['RVOL'] = compute_rvol(vol, 20)

    if 'RelSPY' not in df.columns or df['RelSPY'].isna().all():
        if spy_ref is not None and 'Close' in spy_ref.columns and close is not None:
            df['RelSPY'] = compute_relspy(close, spy_ref['Close'], 20)

    if 'SqueezeHint' not in df.columns or df['SqueezeHint'].isna().all():
        if close is not None and high is not None and low is not None:
            df['SqueezeHint'] = compute_squeeze_hint(close, high, low)

    if 'P_up' not in df.columns or df['P_up'].isna().all():
        rsi = df.get('RSI4')
        rel = df.get('RelSPY')
        if rsi is not None and rel is not None:
            rsi_z = (rsi - 50) / 50.0
            rel_z = rel - 1.0
            score = 0.6*rsi_z + 0.4*rel_z
            p = 1/(1+np.exp(-score))
            df['P_up'] = p

    for c in ['RelSPY','RVOL','RSI4','ConnorsRSI','SqueezeHint','P_up']:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce')

    return df

def report_feature_gaps(df: pd.DataFrame, cols=None) -> pd.DataFrame:
    if cols is None:
        cols = ['P_up','RelSPY','RVOL','RSI4','ConnorsRSI','SqueezeHint']
    res = []
    for c in cols:
        if c in df.columns:
            nulls = df[c].isna().sum()
            res.append((c, nulls))
        else:
            res.append((c, 'missing'))
    return pd.DataFrame(res, columns=['column','null_count'])
